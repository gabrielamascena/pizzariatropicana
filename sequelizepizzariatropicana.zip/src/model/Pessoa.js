
let {Sequelize, DataTypes} = require("sequelize");
let db = require("../db");

const.Pessoa = db.define("Pessoa",
{
    id_pessoa: {
        type: DataTypes.INTEGER
        autoIncrement: true,
        allowNull: false,
        primaryKey: true

    },
    nome: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    endereco: {
       type: DataTypes.STRING,
       allowNull: false,
    },
    telefone: {
        type: DataTypes.INTEGER
        allowNull: false,
    }
);

module.exports = Pessoa;