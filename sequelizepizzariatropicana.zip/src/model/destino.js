let {Sequelize, DataTypes} = require("sequelize");
let db = require("../db");

const.Pessoa = db.define("destino",
{
    id_destino: {
        type: DataTypes.INTEGER
        autoIncrement: true,
        allowNull: false,
        primaryKey: true

    },
    taxa: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    endereco: {
       type: DataTypes.STRING,
       allowNull: false,
    },
    telefone: {
        type: DataTypes.INTEGER
        allowNull: false,
    }
);

module.exports = destino;