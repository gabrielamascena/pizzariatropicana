let {Sequelize, DataTypes} = require("sequelize");
let db = require("../db");

const.Pedido = db.define("pedido",
{
    id: {
        type: DataTypes.INTEGER
        autoIncrement: true,
        allowNull: false,
        primaryKey: true

    },
    sabor: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    tamanho: {
       type: DataTypes.STRING,
       allowNull: false,
    },
    sem_lactose: {
        DataTypes.STRING
    },
    borda: {
        type: DataTypes.STRING
        allowNull: true,
    },
    valorDoPedido: {
       type: DataTypes.INTEGER,
       allowNull: false,
    },
);

module.exports = pedido;