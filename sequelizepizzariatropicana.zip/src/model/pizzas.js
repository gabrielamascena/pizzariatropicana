let {Sequelize, DataTypes} = require("sequelize");
let db = require("../db");

const.Pessoa = db.define("pizza",
{
    id_pizza: {
        type: DataTypes.INTEGER
        autoIncrement: true,
        allowNull: false,
        primaryKey: true

    },
   nome: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    ingredientes: {
       type: DataTypes.STRING,
       allowNull: false,
    },
    familia: {
        type: DataTypes.INTEGER
        allowNull: false,
    },
    pequ: {
        type: DataTypes.INTEGER
        allowNull: false,

);

module.exports = pizza; 